---
name: Logistics Agency Operational Portal
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#5b403b'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#8f7069'
  outline-variant: '#e3beb6'
  surface-tint: '#b62506'
  primary: '#b22204'
  on-primary: '#ffffff'
  primary-container: '#d63c1e'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb4a4'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#825100'
  on-tertiary: '#ffffff'
  tertiary-container: '#a36700'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad3'
  primary-fixed-dim: '#ffb4a4'
  on-primary-fixed: '#3e0500'
  on-primary-fixed-variant: '#8d1600'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
  code-tracking:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes an authoritative, highly functional, and energetic operational workspace for the official logistics agency hub in Canavieiras, Bahia. Balancing the dynamic commerce heritage of express delivery with the rigorous discipline required for high-throughput package intake, sorting, and dispatch, the visual language prioritizes utility, speed, and precision.

The design movement combines **Modern High-Contrast Functionalism** with tactical logistics clarity:
- **Tone:** Methodical, industrious, urgent yet organized, and unmistakably verified.
- **Atmosphere:** Clean white-and-slate surfaces punctuated by vibrant crimson-orange accents, golden warnings, and resolute confirmation greens.
- **Target Audience:** Station managers, package handlers, desk agents, and regional field dispatchers demanding instantaneous legibility under intense operational flow.

## Colors

The palette is engineered for rapid status recognition in high-velocity logistics operations. 

- **Primary Brand Stream (#EE4D2D):** The iconic express red-orange leads primary user actions, focal status anchors, and system branding. Active pressed states pull from `#D03B1F`, while deep structural branding anchors in deep crimson `#991B1B` and dark burgundy `#7F1D1D`.
- **Secondary Structural Stream (#0F172A & #1E293B):** Deep slate and dark navy establish high-contrast structural framing, primary data readouts, sidebars, and critical headers, preventing visual fatigue caused by overusing pure red tones.
- **Warning & In-Transit (#F59E0B, #FBBF24, #D97706):** Warm amber guides pending scans, processing bottlenecks, route dispatches, and attention-required items.
- **Operational Verification (#10B981 & #25D366):** Emerald and WhatsApp-familiar greens are reserved exclusively for scanned package approvals, successfully verified handovers, and positive parcel balance checks.
- **Neutral Surface Foundations:** Pure white `#FFFFFF` canvases with `#F8FAFC` and `#F1F5F9` utility tracks for tabular data alternation, bounded by sharp `#E2E8F0` hairline dividers.

## Typography

The type hierarchy utilizes **Inter** for all interface levels to maximize optical legibility across varying monitor resolutions and scanning angles. Numeric figures must apply tabular figures (`font-variant-numeric: tabular-nums`) across all data tables, manifests, and barcode reference fields to maintain crisp vertical alignment during dynamic counter updates.

For package tracking numbers, AWB references, and driver license plate readouts, **JetBrains Mono** is introduced via the `code-tracking` token to eliminate misread characters (such as 0 vs O, 1 vs I).

## Layout & Spacing

The portal is calibrated for a **Fixed Grid Desktop Framework** designed around standard agency workstation monitors (1440px to 1920px), featuring a fixed vertical operational navigation rail (width: 260px) paired with a responsive 12-column layout for the primary operational canvas.

- **Gutters & Padding:** Standard horizontal gutters are locked at `1.25rem` (20px). Section margins use `2rem` (32px) to frame heavy data sets cleanly without edge crowding.
- **Rhythm:** Dense, metric-driven screens strictly adhere to an 8px spatial grid, utilizing `space-xs` (4px) and `space-sm` (8px) for tightly coupled form elements, tracking chips, and table cells. `space-md` (16px) establishes standard card interior padding, while `space-lg` (24px) separates distinct operational modules.

## Elevation & Depth

Visual hierarchy relies on crisp, high-definition tactile containment designed to resist screen glare in bright warehouse and agency storefront environments:

- **Flat Foundation:** Background is neutral utility `#F8FAFC`. Base panels sit flat with a 1px border of `#E2E8F0`.
- **Card & Tile Elevation (Resting):** `0px 1px 3px rgba(15, 23, 42, 0.08), 0px 1px 2px rgba(15, 23, 42, 0.04)`. Outlined by a razor-thin structural border `#E2E8F0`.
- **Interactive Hover & Scan Focus:** `0px 4px 6px -1px rgba(15, 23, 42, 0.1), 0px 2px 4px -2px rgba(15, 23, 42, 0.06)`. Border color shifts to `#CBD5E1` or `#EE4D2D` on active focus.
- **Modal & Barcode Scanner Overlays:** `0px 20px 25px -5px rgba(15, 23, 42, 0.15), 0px 8px 10px -6px rgba(15, 23, 42, 0.1)` with a backdrop blur of `4px` applied over an operational tint of `rgba(15, 23, 42, 0.4)`.

## Shapes

The geometric framework balances approachable modern interfaces with rigid logistics containers:

- **Standard Cards and Panels:** Strict `16px` (`rounded-lg` under shape factor 2) radius to provide clean separation between shipment batches, intake manifests, and station KPI widgets.
- **Form Controls & Inputs:** `8px` (`0.5rem`) for text boxes, scanner inputs, and actionable filter triggers.
- **Status Pills & Operational Badges:** Full pill-shaped rounding (`9999px`) to create clear semantic differentiation between data cards and status indicators.

## Components

### Buttons & Trigger Actions
- **Primary Operational:** High-visibility `#EE4D2D` background with white text, font weight 600, height 40px, rounded to 8px. Hover state shifts to `#D03B1F`. Active state reveals a deep `#991B1B` inset glow.
- **Secondary Dispatch:** Solid `#0F172A` background with crisp white typography, serving non-intake administrative actions and CSV/manifest export.
- **Confirmation Button:** `#10B981` with white text, deployed for "Finalize Package Batch", "Sign Delivery", or "Confirm Route Release".
- **Ghost/Tertiary:** Transparent fill, `#64748B` label with `#E2E8F0` border, shifting to `#F1F5F9` on hover.

### Badge Pills (Status Indicators)
- Pill-shaped (`rounded-full`), padding `2px 10px`, typography `label-sm` uppercase.
- **Delivered / Confirmed:** Background `#ECFDF5`, text `#065F46`, left-aligned `6px` solid dot in `#10B981`.
- **In Sorting / Transit:** Background `#FEF3C7`, text `#92400E`, dot in `#F59E0B`.
- **Awaiting Intake / Exception:** Background `#FEF2F2`, text `#991B1B`, dot in `#EE4D2D`.
- **Agency Stored / Canavieiras Hub:** Background `#F1F5F9`, text `#1E293B`, dot in `#0F172A`.

### Operational Data Cards
- Container geometry: 16px corner radius, `#FFFFFF` background, hairline border in `#E2E8F0`, padding `20px`.
- Highlighting metrics: Metric value in `headline-lg` (`#0F172A`), paired with contextual comparison pill and micro-label in `label-md`.

### Barcode & Package Input Fields
- Monospaced numeric support, explicit focus ring `2px solid #EE4D2D` with an offset of `1px`.
- Left-adorned with high-contrast hardware scanner icon indicators; trailing badge displaying current batch count.

### Manifest Tables & Lists
- Row height: 48px fixed for maximum scanning throughput.
- Header: `#F8FAFC` background, uppercase `label-sm` font in `#64748B`, with thin bottom border in `#CBD5E1`.
- Alternate row striping on mouseover using `#F8FAFC`.
- Action buttons in table rows must remain static to eliminate misclicks during batch verification.